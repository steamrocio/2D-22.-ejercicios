#include <iostream>
using namespace  std;
 
 int main(){
 	double nota;
 	cout << "ingresar la nota del examen del informatica" << endl;
 	cin >> nota;
 	cout<< "la nota del examen es: " << nota <<endl;
 }
