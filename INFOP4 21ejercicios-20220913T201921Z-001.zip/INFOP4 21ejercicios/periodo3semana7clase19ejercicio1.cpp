#include<iostream>
using namespace std;
int main(){
	int n1, n2, c;
	cout<<"Ingresar el primer numero:";
	cin>>n1;
	cout<<"Ingresar el segundo numero:";
	cin>>n1;
	c = n1;
	while (c > n2){
		cout<< c <<end1;
		c--;
	}
	return 0;
}
