#include <iostream>
 using namespace std;
int main(){
	int n1,n2; cout<< " Ingrese el primer numero : ";
	cin >> n1;
	cout << " Ingrese el segundo numero : ";
	cin>> n2;
	if (n1 > n2){
		cout << "el numero " << n1 << "es mayor al numero " << n2 << endl;
	}else{
	cout << "el numero " << n2 << "es mayor al numero " << n1 << endl;
		}
}

